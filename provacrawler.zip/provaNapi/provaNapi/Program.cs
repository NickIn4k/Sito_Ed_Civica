﻿using System;
using HtmlAgilityPack;

/* 
 il problema che il crawler tanto dipende dalla pagina HTML
quindi devo sapere la struttura della pagina(quali dati sono nei quali tag)
 in piu, anche se cambiano la struttura della pagina puo diventare inutile
 è meglio del modo con API perche è 100% gratis

quindi o devo trovare i dati solo nei siti con la stessa struttura
o sperare(intendo piangere)
 */
class Program
{
    static void Main(string[] args)
    {
        // URL del sito da cui ottenere i dati. Sostituire con un URL valido di un sito meteo che supporti l'accesso ai dati necessari.
        string url = "https://www.weather.com/weather/today/l/Moscow";

        try
        {
            // Creazione di un oggetto HtmlWeb per il caricamento della pagina
            HtmlWeb web = new HtmlWeb();
            HtmlDocument document = web.Load(url);

            // Estrazione del nome della città. L'XPath viene determinato in base alla struttura del sito
            var cityNode = document.DocumentNode.SelectSingleNode("//h1[contains(@class, 'CurrentConditions--location')]");
            string city = cityNode != null ? cityNode.InnerText.Trim() : "City not found";

            // Estrazione della temperatura
            var tempNode = document.DocumentNode.SelectSingleNode("//span[contains(@class, 'CurrentConditions--tempValue')]");
            string temperature = tempNode != null ? tempNode.InnerText.Trim() : "Temperature not found";

            // Estrazione della descrizione delle condizioni meteorologiche
            var conditionNode = document.DocumentNode.SelectSingleNode("//div[contains(@class, 'CurrentConditions--phrase')]");
            string condition = conditionNode != null ? conditionNode.InnerText.Trim() : "Condition not found";

            // Visualizzazione dei dati
            Console.WriteLine($"City: {city}");
            Console.WriteLine($"Temperature: {temperature}");
            Console.WriteLine($"Condition: {condition}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error while fetching weather data: {ex.Message}");
        }
    }
}
