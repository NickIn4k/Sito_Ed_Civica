﻿using System; // Importa lo spazio dei nomi base per utilizzare funzionalità fondamentali come la classe Console.
using System.Net.Http; // Importa lo spazio dei nomi per eseguire richieste HTTP, utile per inviare/ricevere dati da API web.
using System.Threading.Tasks; // Importa lo spazio dei nomi per gestire la programmazione asincrona con async e Task.
using Newtonsoft.Json.Linq; // Importa lo spazio dei nomi per lavorare con oggetti JSON in modo strutturato, fornito dalla libreria Newtonsoft.Json.

class Program // Definisce una classe denominata "Program", il punto di ingresso per l'applicazione.
{
    static async Task Main(string[] args) // Definisce il metodo principale del programma come asincrono per gestire operazioni che richiedono tempo (es. richieste HTTP).
    {
        string apiKey = "70edf648ee0b4a30ac7121805241012"; // Chiave API utilizzata per autenticarsi con il servizio WeatherAPI.
        string location = "Moscow"; // Specifica la località (città) per la quale vogliamo ottenere i dati meteo.
        string url = $"https://api.weatherapi.com/v1/current.json?key={apiKey}&q={location}&aqi=no";
        // URL della richiesta HTTP che include la chiave API, la località e l'opzione "aqi=no" per non includere dati sulla qualità dell'aria.

        using (HttpClient client = new HttpClient()) // Crea un'istanza di HttpClient per inviare richieste HTTP. "using" assicura che venga eliminato correttamente dopo l'uso.
        {
            try // Inizio del blocco "try" per gestire eventuali eccezioni che potrebbero verificarsi durante la richiesta HTTP.
            {
                HttpResponseMessage response = await client.GetAsync(url);
                // Esegue una richiesta HTTP GET in modo asincrono per ottenere i dati dal servizio API.

                response.EnsureSuccessStatusCode();
                // Controlla se la risposta HTTP ha uno stato di successo (es. 200 OK). Se no, genera un'eccezione.

                string responseData = await response.Content.ReadAsStringAsync();
                // Legge il contenuto della risposta HTTP come stringa, anch'esso in modo asincrono.

                var weatherData = JObject.Parse(responseData);
                // Parsea (analizza) la stringa JSON della risposta in un oggetto JObject per facilitarne l'accesso ai dati.

                string cityName = weatherData["location"]["name"].ToString();
                // Estrae il nome della città dal nodo "location" nel JSON e lo converte in una stringa.

                double tempC = double.Parse(weatherData["current"]["temp_c"].ToString());
                // Estrae la temperatura corrente in gradi Celsius dal nodo "current" e la converte in double.

                string condition = weatherData["current"]["condition"]["text"].ToString();
                // Estrae la descrizione delle condizioni meteorologiche (es. "Soleggiato") dal nodo "condition".

                Console.WriteLine($"city: {cityName}");
                // Stampa il nome della città sulla console.

                Console.WriteLine($"temperature: {tempC}°C");
                // Stampa la temperatura corrente con l'unità di misura °C.

                Console.WriteLine($"weather: {condition}");
                // Stampa la descrizione delle condizioni meteorologiche sulla console.
            }
            catch (HttpRequestException ex) // Cattura eventuali errori relativi alla richiesta HTTP.
            {
                Console.WriteLine($"Errore durante la richiesta dei dati: {ex.Message}");
                // Stampa un messaggio di errore che descrive il problema accaduto.
            }
        } // Chiude il blocco "using", rilasciando le risorse allocate per l'istanza di HttpClient.
    }
}
